//
//  main.m
//  事件加入到日历
//
//  Created by ZhangCheng on 14-4-26.
//  Copyright (c) 2014年 张诚. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZCAppDelegate class]));
    }
}
